import { getStore } from '@netlify/blobs';

const headers = {
  'Content-Type': 'application/json; charset=utf-8',
  'Cache-Control': 'no-store, no-cache, must-revalidate',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS'
};

const emptyState = { reports: [], customers: [], products: {}, updatedAt: 0 };

function response(status, body) {
  return new Response(JSON.stringify(body), { status, headers });
}

export default async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers });
  if (req.method !== 'POST') return response(405, {ok:false,message:'Method not allowed'});

  try {
    const store = getStore({ name: 'mehrabi-shop-data', consistency: 'strong' });
    const body = await req.json();
    const current = (await store.get('state', { type: 'json', consistency: 'strong' })) || emptyState;

    if (body.action === 'health') return response(200, {ok:true, service:'shop-data', stateVersion: current.updatedAt || 0});
    if (body.action === 'get') return response(200, {ok:true, state:current});

    if (body.action === 'clearReports') {
      const next = {...current, reports:[], updatedAt:Date.now()};
      await store.setJSON('state', next);
      return response(200, {ok:true,state:next});
    }

    if (body.action === 'save') {
      const incoming = body.state || {};
      const rm = new Map();
      for (const r of [...(current.reports || []), ...(incoming.reports || [])]) {
        if (!r || r.id == null) continue;
        const key = String(r.id);
        const old = rm.get(key);
        const oldTime = Number(old?.createdAt || old?.updatedAt || old?.id || 0);
        const newTime = Number(r.createdAt || r.updatedAt || r.id || 0);
        if (!old || newTime >= oldTime) rm.set(key, {...r, createdAt:Number(r.createdAt || r.id || Date.now())});
      }
      const reports = Array.from(rm.values()).sort((a,b)=>Number(b.createdAt||b.id||0)-Number(a.createdAt||a.id||0));
      const customers = [...new Set([...(current.customers||[]), ...(incoming.customers||[])])];
      const products = {...(current.products||{})};
      for (const [barcode,item] of Object.entries(incoming.products||{})) {
        if (!products[barcode] || Number(item?.updatedAt||0) >= Number(products[barcode]?.updatedAt||0)) products[barcode] = item;
      }
      const merged = {reports,customers,products,updatedAt:Date.now()};
      await store.setJSON('state', merged);
      return response(200, {ok:true,state:merged});
    }

    return response(400, {ok:false,message:'عملیات نامعتبر است.'});
  } catch (e) {
    return response(500, {ok:false,message:e.message || 'خطای ذخیره ابری'});
  }
};
