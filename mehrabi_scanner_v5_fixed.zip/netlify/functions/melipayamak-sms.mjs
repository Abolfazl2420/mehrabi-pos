const HEADERS = {
  'Content-Type': 'application/json; charset=utf-8',
  'Cache-Control': 'no-store',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS'
};

function json(statusCode, data) {
  return { statusCode, headers: HEADERS, body: JSON.stringify(data) };
}

function normalizePhone(value) {
  let p = String(value || '').trim().replace(/[\s()-]/g, '');
  if (p.startsWith('+98')) p = '0' + p.slice(3);
  else if (p.startsWith('98')) p = '0' + p.slice(2);
  if (/^9\d{9}$/.test(p)) p = '0' + p;
  return p;
}

function explainCode(value) {
  const s = String(value).trim();
  const map = {
    '-110': 'این وب‌سرویس نیاز به ApiKey دارد. API Key را از پنل ملی پیامک وارد کنید.',
    '-109': 'IP مجاز برای API تنظیم نشده است. از پشتیبانی ملی پیامک بخواهید IP خروجی را مجاز کند.',
    '-108': 'IP به‌دلیل تلاش ناموفق API مسدود شده است.',
    '-7': 'خطایی در شماره فرستنده رخ داده؛ با پشتیبانی ملی پیامک تماس بگیرید.',
    '-5': 'تعداد یا ترتیب متغیرهای پترن با پترن ثبت‌شده همخوانی ندارد.',
    '-4': 'کد پترن صحیح نیست یا هنوز توسط مدیر سامانه تأیید نشده است.',
    '-3': 'خط ارسال در سیستم تعریف نشده است.',
    '-2': 'هر بار فقط یک شماره گیرنده مجاز است.',
    '-1': 'دسترسی وب‌سرویس برای این حساب فعال نیست.',
    '0': 'نام کاربری یا ApiKey صحیح نیست.',
    '2': 'اعتبار کافی نیست.',
    '8': 'متن شامل کلمه فیلترشده است.',
    '10': 'کاربر فعال نیست.',
    '16': 'شماره گیرنده پیدا نشد.',
    '17': 'متن پیامک خالی است.',
    '18': 'شماره گیرنده نامعتبر است.',
    '19': 'از محدودیت ساعتی عبور کرده‌اید.'
  };
  return map[s] || `کد پنل: ${s}`;
}

async function postForm(operation, params) {
  const body = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => body.set(k, String(v ?? '')));
  const response = await fetch(`https://rest.payamak-panel.com/api/SendSMS/${operation}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
    body
  });
  const raw = await response.text();
  let parsed = null;
  try { parsed = JSON.parse(raw); } catch (_) {}
  return { response, raw, parsed };
}

export default async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: HEADERS });
  if (req.method !== 'POST') return new Response(JSON.stringify({ok:false,message:'Method not allowed'}), {status:405, headers:HEADERS});

  try {
    const body = await req.json();
    const username = String(body.username || '').trim();
    const apiKey = String(body.apiKey || '').trim();
    if (!username || !apiKey) return new Response(JSON.stringify({ok:false,message:'نام کاربری و API Key لازم است.'}), {status:400, headers:HEADERS});

    if (body.action === 'credit') {
      const { response, raw, parsed } = await postForm('GetCredit', { UserName: username, PassWord: apiKey });
      const value = parsed?.Value ?? parsed?.value ?? parsed?.RetStatus ?? parsed?.retStatus ?? raw.trim();
      const status = parsed?.RetStatus ?? parsed?.retStatus;
      if (!response.ok) return new Response(JSON.stringify({ok:false,message:`خطای HTTP ${response.status}`}), {status:502, headers:HEADERS});
      if (status != null && Number(status) < 0) return new Response(JSON.stringify({ok:false,message:explainCode(status), raw}), {status:502,headers:HEADERS});
      return new Response(JSON.stringify({ok:true,credit:value,raw}), {status:200,headers:HEADERS});
    }

    if (body.action === 'send') {
      const to = normalizePhone(body.to);
      const bodyId = String(body.bodyId || '').trim();
      const text = String(body.text || '');
      if (!/^09\d{9}$/.test(to)) return new Response(JSON.stringify({ok:false,message:'شماره گیرنده باید به شکل 09xxxxxxxxx باشد.'}), {status:400,headers:HEADERS});
      if (!bodyId || !text) return new Response(JSON.stringify({ok:false,message:'Body ID یا متغیرهای پترن خالی است.'}), {status:400,headers:HEADERS});

      // BaseServiceNumber is the REST equivalent of the pattern service.
      const { response, raw, parsed } = await postForm('BaseServiceNumber', {
        username,
        password: apiKey,
        text,
        to,
        bodyId
      });

      const value = parsed?.Value ?? parsed?.value ?? parsed?.RetStatus ?? parsed?.retStatus ?? raw.trim();
      const numeric = Number(value);
      const status = parsed?.RetStatus ?? parsed?.retStatus;
      const success = (Number.isFinite(numeric) && numeric > 100000000000000) || (status != null && Number(status) === 1);

      if (!response.ok || !success) {
        return new Response(JSON.stringify({ok:false,message:explainCode(value),code:String(value),raw}), {status:502,headers:HEADERS});
      }
      return new Response(JSON.stringify({ok:true,recId:String(value),message:'پیامک با موفقیت برای ارسال ثبت شد.',to}), {status:200,headers:HEADERS});
    }

    return new Response(JSON.stringify({ok:false,message:'عملیات نامعتبر است.'}), {status:400,headers:HEADERS});
  } catch (e) {
    return new Response(JSON.stringify({ok:false,message:e.message || 'خطای سرور پیامک'}), {status:500,headers:HEADERS});
  }
};
