نسخه V4 اسکنر مواد غذایی مهرابی

1) همگام‌سازی: Netlify Function با Netlify Blobs + netlify.toml + package.json اضافه شده است.
2) دوربین: دوربین پشت، کیفیت 1280x720، فوکوس پیوسته در صورت پشتیبانی، ZXing با TRY_HARDER و فرمت‌های رایج بارکد، و BarcodeDetector در Chromeهای پشتیبانی‌شده.
3) PWA: manifest معتبر، start_url، scope، آیکون 192/512، service worker و دکمه نصب.

کل پوشه/ZIP را Deploy کن. اگر Netlify Site از Git استفاده می‌کند، package.json و netlify.toml باید در ریشه repository باشند.
بعد از Deploy جدید، یک بار Chrome را Refresh کن و در صورت باقی‌ماندن نسخه قدیمی: Chrome > Site settings > Storage > Clear & reset را برای سایت انجام بده.
